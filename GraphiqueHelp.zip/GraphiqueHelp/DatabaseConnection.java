import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DatabaseConnection {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/infographie_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "password";

    public static User getUserByEmailAndPassword(String email, String password) {
        User user = null;
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM users WHERE email = ? AND password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                UserType type = UserType.valueOf(resultSet.getString("type"));
                user = new User(id, name, email, password, type);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

    public static void saveQuestion(Question question) {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO questions (text, image, option1, option2, option3, option4, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, question.getText());
            preparedStatement.setString(2, question.getImage());
            preparedStatement.setString(3, question.getOptions()[0]);
            preparedStatement.setString(4, question.getOptions()[1]);
            preparedStatement.setString(5, question.getOptions()[2]);
            preparedStatement.setString(6, question.getOptions()[3]);
            preparedStatement.setInt(7, question.getCorrectAnswer());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static Question getRandomQuestion() {
        Question question = null;
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM questions ORDER BY RAND() LIMIT 1";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int id = resultSet.getInt("id");
                String text = resultSet.getString("text");
                String image = resultSet.getString("image");
                String[] options = {resultSet.getString("option1"), resultSet.getString("option2"), resultSet.getString("option3"), resultSet.getString("option4")};
                int correctAnswer = resultSet.getInt("correct_answer");
                question = new Question(id, text, image, options, correctAnswer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return question;
    }
}