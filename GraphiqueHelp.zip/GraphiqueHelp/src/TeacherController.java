import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class TeacherController {
    @FXML
    private TextField questionField;
    @FXML
    private TextField option1Field;
    @FXML
    private TextField option2Field;
    @FXML
    private TextField option3Field;
    @FXML
    private TextField option4Field;
    @FXML
    private Button createQuestionButton;

    @FXML
    public void createQuestion() {
        String questionText = questionField.getText();
        String[] options = {option1Field.getText(), option2Field.getText(), option3Field.getText(), option4Field.getText()};
        int correctAnswer = 0; // assume first option is correct
        Question question = new Question(0, questionText, "", options, correctAnswer);
        DatabaseConnection.saveQuestion(question);
    }

    @FXML
    public void createTest() {
        // create test with 5 random questions
    }
}