import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class AdminController {
    @FXML
    private TextField emailField;
    @FXML
    private TextField passwordField;
    @FXML
    private Button loginButton;

    @FXML
    public void login() {
        String email = emailField.getText();
        String password = passwordField.getText();
        User user = DatabaseConnection.getUserByEmailAndPassword(email, password);
        if (user!= null && user.getType() == UserType.ADMIN) {
            // login successful, navigate to admin dashboard
        } else {
            // login failed, display error message
        }
    }

    @FXML
    public void createUser() {
        // create new user account
    }

    @FXML
    public void deleteUser() {
        // delete user account
    }
}