public enum UserType {
    STUDENT, TEACHER, ADMIN
}