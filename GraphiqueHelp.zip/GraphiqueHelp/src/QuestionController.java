
// QuestionController.java
package com.example.infographieapp.controllers;

import com.example.infographieapp.models.Question;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class QuestionController {

    @FXML
    private TextField questionTextField;
    @FXML
    private TextField answerAField;
    @FXML
    private TextField answerBField;
    @FXML
    private TextField answerCField;
    @FXML
    private TextField answerDField;
    @FXML
    private TextField correctAnswerField;

    @FXML
    private void handleSaveQuestionButtonAction() {
        Question question = new Question();
        question.setText(questionTextField.getText());
        question.setAnswerA(answerAField.getText());
        question.setAnswerB(answerBField.getText());
        question.setAnswerC(answerCField.getText());
        question.setAnswerD(answerDField.getText());
        question.setCorrectAnswer(correctAnswerField.getText());

        saveQuestionToDatabase(question);
    }

    private void saveQuestionToDatabase(Question question) {
        // Logique pour sauvegarder la question dans la base de données
    }
}
