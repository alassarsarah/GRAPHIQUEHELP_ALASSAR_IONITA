// TestGenerator.java
package com.example.infographieapp.utils;

import com.example.infographieapp.models.Question;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class TestGenerator {

    public void generateTest(List<Question> questions) {
        try {
            FileWriter writerWithAnswers = new FileWriter("test_with_answers.txt");
            FileWriter writerWithoutAnswers = new FileWriter("test_without_answers.txt");

            for (Question question : questions) {
                writerWithAnswers.write(formatQuestionWithAnswer(question));
                writerWithoutAnswers.write(formatQuestionWithoutAnswer(question));
            }

            writerWithAnswers.close();
            writerWithoutAnswers.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String formatQuestionWithAnswer(Question question) {
        return question.getText() + "\n" +
                "A: " + question.getAnswerA() + "\n" +
                "B: " + question.getAnswerB() + "\n" +
                "C: " + question.getAnswerC() + "\n" +
                "D: " + question.getAnswerD() + "\n" +
                "Correct Answer: " + question.getCorrectAnswer() + "\n\n";
    }

    private String formatQuestionWithoutAnswer(Question question) {
        return question.getText() + "\n" +
                "A: " + question.getAnswerA() + "\n" +
                "B: " + question.getAnswerB() + "\n" +
                "C: " + question.getAnswerC() + "\n" +
                "D: " + question.getAnswerD() + "\n\n";
    }
}
