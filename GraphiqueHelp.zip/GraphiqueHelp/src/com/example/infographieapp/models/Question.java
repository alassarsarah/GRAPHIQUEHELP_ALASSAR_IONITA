// Question.java
package com.example.infographieapp.models;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class Question {
    private int id;
    private String text;
    private String imagePath;
    private String answerA;
    private String answerB;
    private String answerC;
    private String answerD;
    private String correctAnswer;

    public void setAnswerB(String text) {
    }

    public void setCorrectAnswer(String text) {
    }

    public void setAnswerA(String text) {
    }

    public void setText(String text) {
    }

    public void setAnswerC(String text) {
    }

    public void setAnswerD(String text) {
    }

    public String getText() {
        return "";
    }

    public String getAnswerA() {
        return "";
    }

    public String getAnswerB() {
        return "";
    }

    public String getAnswerC() {
        return "";
    }

    public String getAnswerD() {
        return "";
    }

    public String getCorrectAnswer() {
        return "";
    }

    // Getters et Setters
}
