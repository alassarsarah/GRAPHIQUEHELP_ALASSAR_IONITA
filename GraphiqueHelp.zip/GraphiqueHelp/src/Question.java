
public class Question {
    private int id;
    private String text;
    private String image;
    private String[] options;
    private int correctAnswer;

    public Question(int id, String text, String image, String[] options, int correctAnswer) {
        this.id = id;
        this.text = text;
        this.image = image;
        this.options = options;
        this.correctAnswer = correctAnswer;
    }

    public String getText() {
        return "";
    }

    // getters and setters
}