import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class StudentController {
    @FXML
    private Label questionLabel;
    @FXML
    private Button option1Button;
    @FXML
    private Button option2Button;
    @FXML
    private Button option3Button;
    @FXML
    private Button option4Button;
    @FXML
    private Button submitButton;

    @FXML
    public void startTest() {
        // generate 5 random questions
        Question question = DatabaseConnection.getRandomQuestion();
        questionLabel.setText(question.getText());
        // set options and correct answer
    }

    @FXML
    public void submitAnswer() {
        // submit answer and get feedback
    }
}