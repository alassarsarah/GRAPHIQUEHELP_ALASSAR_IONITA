public class User {
    private int id;
    private String email;
    private String password;
    private UserType type;

    public User(int id, String email, String password, UserType type) {
        this.id = id;
        this.email = email;
        this.password = password;
        this.type = type;
    }

    public UserType getType() {
        return null;
    }

    // getters and setters
}